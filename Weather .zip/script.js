const wrapper = document.querySelector('.wrapper'); // Changed from '.container' to '.wrapper'
const searchBtn = document.querySelector('.search-btn');
const cityInput = document.getElementById('mycity');
const weatherBox = document.querySelector('.weather-box');
const weatherDetails = document.querySelector('.weather-details');
const error404 = document.querySelector('.not-found');

// Function to handle weather search
const searchWeather = () => {
    const APIKey = '5e65ff78cec6182473333749107079a5'; // Get from OpenWeatherMap
    const city = cityInput.value.trim();

    if (city === '')
        return;

    fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${APIKey}`)
        .then(response => response.json())
        .then(json => {
            if (json.cod === '404' || json.cod === 404) {
                wrapper.style.height = '400px'; // Changed from container to wrapper
                wrapper.classList.add('active'); // Add active class for proper styling
                weatherBox.style.display = 'none';
                weatherDetails.style.display = 'none';
                error404.style.display = 'block';
                error404.classList.add('fadeIn');
                return;
            }

            error404.style.display = 'none';
            error404.classList.remove('fadeIn');

            const image = document.querySelector('.weather-box img');
            const temperature = document.querySelector('.weather-box .temperature');
            const description = document.querySelector('.weather-box .description');
            const humidity = document.querySelector('.weather-details .humidity span');
            const wind = document.querySelector('.weather-details .wind span');

            switch (json.weather[0].main) {
                case 'Clear':
                    image.src = 'https://raw.githubusercontent.com/codewithsadee/weather-app/master/assets/images/clear.png';
                    break;
                case 'Rain':
                    image.src = 'https://raw.githubusercontent.com/codewithsadee/weather-app/master/assets/images/rain.png';
                    break;
                case 'Snow':
                    image.src = 'https://raw.githubusercontent.com/codewithsadee/weather-app/master/assets/images/snow.png';
                    break;
                case 'Clouds':
                    image.src = 'https://raw.githubusercontent.com/codewithsadee/weather-app/master/assets/images/cloud.png';
                    break;
                case 'Haze':
                case 'Mist':
                    image.src = 'https://raw.githubusercontent.com/codewithsadee/weather-app/master/assets/images/mist.png';
                    break;
                default:
                    image.src = '';
            }

            temperature.innerHTML = `${parseInt(json.main.temp)}<span>°C</span>`;
            description.innerHTML = `${json.weather[0].description}`;
            humidity.innerHTML = `${json.main.humidity}%`;
            wind.innerHTML = `${parseInt(json.wind.speed)}Km/h`;

            weatherBox.style.display = 'block';
            weatherDetails.style.display = 'flex';
            weatherBox.classList.add('fadeIn');
            weatherDetails.classList.add('fadeIn');
            wrapper.classList.add('active'); // Add active class for proper styling
        })
        .catch(error => {
            console.error('Error fetching weather data:', error);
        });
};

// Add click event listener to the search button
searchBtn.addEventListener('click', searchWeather);

// Add enter key event listener to the input field
cityInput.addEventListener('keypress', (event) => {
    if (event.key === 'Enter') {
        searchWeather();
    }
});
